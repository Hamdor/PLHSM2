#include <iostream>
#include "timer.hpp"

Timer::Timer(int chid, int sec, int msec, int i_sec, int i_msec, int pulse_code, int pulse_value) {

  // Establish connection Client -> Server
  if ((coid = ConnectAttach(0, 0, chid, _NTO_SIDE_CHANNEL, 0)) == -1) {
    std::cout << "[TIMER]: Unable to attach conenction!" << std::endl;
  }

  // Initialisation of signal event structure via macro
  SIGEV_PULSE_INIT(&event, coid, SIGEV_PULSE_PRIO_INHERIT, pulse_code, pulse_value);

  // Create timer
  if (timer_create(CLOCK_REALTIME, &event, &timerid) == -1) {
    std::cout << "[TIMER]: Unable to create timer!" << std::endl;
  }

  // Save initial values for eventual reset
  seconds = sec;
  milliSeconds = msec;
  i_seconds = i_sec;
  i_milliSeconds = i_msec;
  isPaused = false;
  resetTimer(); // Reset timer initial values
}

Timer::~Timer() {
  if (ConnectDetach(coid) == -1) {
    std::cout << "[~TIMER]: Unable to detach connection!" << std::endl;
  }
  if (timer_delete(timerid) == -1) {
    std::cout << "[~TIMER]: Unable to delete timer!" << std::endl;
  }
}

void Timer::startTimer() {
  if (!isStarted) {
    if (timer_settime(timerid, 0, &timer, NULL) == -1) {
      std::cout << "[TIMER]: Unable to start timer!" << std::endl;
    }
    isStarted = true;
  }
}

void Timer::stopTimer() {
  if (timer_settime(timerid, 0, &timer, NULL) == -1) {
    std::cout << "[TIMER]: Unable to stop timer!" << std::endl;
  }
  resetTimer(); // Reset timer to initial values
}

void Timer::pauseTimer() {
  if (isStarted && !isPaused) {
    if (timer_settime(timerid, 0, &timer, &currentTimer) == -1) {
      std::cout << "[TIMER]: Unable to pause timer!" << std::endl;
    }
    isPaused = true;
  }
}

void Timer::continueTimer() {
  if (isStarted && isPaused) {
    if (timer_settime(timerid, 0, &currentTimer, NULL) == -1) {
      std::cout << "[TIMER]: Unable to continue timer!" << std::endl;
    }
    isPaused = false;
  }
}

void Timer::resetTimer() {
  timer.it_value.tv_sec = seconds;
  timer.it_value.tv_nsec = milliSeconds * CONVERT_MSEC_2_NSEC;
  timer.it_interval.tv_sec = i_seconds;
  timer.it_interval.tv_nsec = i_milliSeconds * CONVERT_MSEC_2_NSEC;
  isStarted = false;
}
