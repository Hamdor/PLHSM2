#include "ampel.hpp"

void ampel::tick() {
  current_state->tick();
}
