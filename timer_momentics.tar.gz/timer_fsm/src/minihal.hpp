#ifndef MINIHAL_HPP_
#define MINIHAL_HPP_

class mini_hal {
  mini_hal();
  virtual ~mini_hal();
 public:
  void lampe_on();
  void lampe_off();
  static mini_hal* get_instance();
  static mini_hal* instance;
};

#endif /* MINIHAL_HPP_ */
