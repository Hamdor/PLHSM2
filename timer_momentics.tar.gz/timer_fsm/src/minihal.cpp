#include "minihal.h"

#include <hw/inout.h>
#include <sys/neutrino.h>
#ifdef SIMULATION
 #include <ioaccess.h>
#endif

mini_hal* mini_hal::instance = 0;

mini_hal::mini_hal() {
  out8(0x303, 0x82);
}

mini_hal::~mini_hal() {

}

void mini_hal::lampe_off() {
  out8(0x300, in8(0x300) & ~(0x01 << 5));
}

void mini_hal::lampe_on() {
  out8(0x300, in8(0x300) | (0x01 << 5));
}

mini_hal* mini_hal::get_instance() {
  ThreadCtl(_NTO_TCTL_IO_PRIV, NULL);
  if (!instance) {
    instance = new mini_hal();
  }
  return instance;
}
