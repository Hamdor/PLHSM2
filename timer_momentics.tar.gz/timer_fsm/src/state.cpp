#include "state.hpp"
#include "minihal.hpp"

void aus::tick() {
  mini_hal::get_instance()->lampe_on();
  new (this) an;
}

void an::tick() {
  mini_hal::get_instance()->lampe_off();
  new (this) aus;
}
