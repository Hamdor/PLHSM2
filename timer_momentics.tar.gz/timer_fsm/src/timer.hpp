#ifndef TIMER_HPP_
#define TIMER_HPP_

#include <time.h>
#include <sys/neutrino.h>

#define CONVERT_MSEC_2_NSEC 1000000
#define PULSE_ID 123 // TODO: Move to global header file

class Timer {
 public:
  Timer(int chid, int sec, int msec, int i_sec, int i_msec, int pulse_code, int pulse_value);
  ~Timer();             // Destructor
  void startTimer();    // Start
  void stopTimer();     // Stop
  void pauseTimer();    // Pause
  void continueTimer(); // Continue
  void resetTimer();    // Reset timer to initial values

 private:
  timer_t timerid;                // Timer ID
  struct itimerspec timer;        // Timer structure
  struct itimerspec currentTimer; // Current timer values for continuation
  struct sigevent event;          // Signal event structure
  int coid;                       // Connection ID to server
  int seconds;                    // Seconds value for one-shot delay
  int milliSeconds;               // Milliseconds value for one-shot delay
  int i_seconds;                  // Seconds value for interval
  int i_milliSeconds;             // Milliseconds value for interval
  bool isStarted;                 // Timer was started
  bool isPaused;                  // Timer was paused
};

#endif /* TIMER_HPP_ */
