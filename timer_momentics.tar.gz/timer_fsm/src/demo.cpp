#include <cstdlib>
#include <iostream>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <sys/siginfo.h>
#include <sys/neutrino.h>

#include "ampel.hpp"
#include "timer.hpp"

#ifdef SIMULATION
 #include <ioaccess.h>
#endif

int main(int argv, char* argc[]) {

#ifdef SIMULATION
    IOaccess_open();
#endif

  struct _pulse pulse; // Pulse message for communication
  int recvID;          // Process ID of the sender
  ampel c;             // Context Class

  // Client creates channel for communication
  int chid = ChannelCreate(0); // Channel ID
  if (chid == -1) {
    std::cerr << "[MAIN]: Unable to create channel!" << std::endl;
    exit (EXIT_FAILURE);
  }

  // Create and start timer
  Timer t1 = Timer(chid, 1, 0 , 1, 500, 1, 42);
  t1.startTimer();

  for(int i = 0; i < 10; ++i) {
    recvID = MsgReceivePulse(chid , &pulse , sizeof(pulse), NULL); // Blocked receive
    if(pulse.code == 1) {
      std::cout << "Timer value: " << pulse.value.sival_int << std::endl;
      c.tick();
    }
  }

#ifdef SIMULATION
   IOaccess_close();
#endif

  return EXIT_SUCCESS;
}
