#ifndef STATE_HPP_
#define STATE_HPP_

#include <cstdlib>
#include <iostream>

class State {
 public:
  virtual ~State() { }
  virtual void tick() { }
};

class aus : public State {
 public:
  void tick();
};

class an : public State {
 public:
  void tick();
};

#endif /* STATE_HPP_ */
