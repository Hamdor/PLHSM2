#ifndef CONVEYOR_HPP_
#define CONVEYOR_HPP_

#include "state.hpp"

class ampel {
 public:
  ampel() : current_state(new aus) { }
  ~ampel() { delete current_state; }
  void tick();
 private:
  State* current_state;
};

#endif /* CONVEYOR_HPP_ */
