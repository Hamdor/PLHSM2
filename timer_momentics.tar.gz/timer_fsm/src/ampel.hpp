#ifndef AMPEL_HPP_
#define AMPEL_HPP_

#include "state.hpp"

class ampel {
 public:
  ampel() : current_state(new aus) { }
  ~ampel() { delete current_state; }
  void tick();
 private:
  State* current_state;
};

#endif /* AMPEL_HPP_ */
